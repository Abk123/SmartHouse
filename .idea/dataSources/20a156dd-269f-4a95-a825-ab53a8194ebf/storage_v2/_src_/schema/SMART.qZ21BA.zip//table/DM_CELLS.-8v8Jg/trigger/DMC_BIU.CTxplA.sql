CREATE TRIGGER DMC_BIU
  BEFORE INSERT OR UPDATE
  ON DM_CELLS
  FOR EACH ROW
  BEGIN
    :new.cell_address := upper(:new.cell_address);
    :new.cell_name := upper(:new.cell_name);
    :new.read_enabled := upper(:new.read_enabled);
    :new.write_enabled := upper(:new.write_enabled);
    :new.min_value_cell_address := upper(:new.min_value_cell_address);
    :new.max_value_cell_address := upper(:new.max_value_cell_address);
    :new.create_stat_table := upper(:new.create_stat_table);
    :new.stat_table_abbr := upper(:new.stat_table_abbr);
END;

/

