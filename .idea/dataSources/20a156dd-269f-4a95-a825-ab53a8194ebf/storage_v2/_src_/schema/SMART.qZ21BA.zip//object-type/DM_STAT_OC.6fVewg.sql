CREATE TYPE         "DM_STAT_OC"                                          
AS TABLE OF dm_stat_o;
/

