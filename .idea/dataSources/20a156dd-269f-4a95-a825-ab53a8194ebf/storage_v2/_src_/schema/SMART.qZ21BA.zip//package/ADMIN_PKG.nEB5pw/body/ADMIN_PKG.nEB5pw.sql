CREATE PACKAGE BODY       admin_pkg
AS
   PROCEDURE create_stat_table (i_day_of_month   IN DATE /*Дата месяца,за который формируется таблица*/
                                                        ,
                                i_table_name     IN VARCHAR2 /*Наименование таблицы*/
                                                            ,
                                i_table_abbr     IN VARCHAR2 /*Аббревиатура таблицы*/
                                                            )
   AS
      p_day_from     DATE;
      p_day_to       DATE;
      p_day          DATE;
      p_tablespace   VARCHAR2 (30);
      p_sql          VARCHAR2 (32000);
      p_cnt          NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO p_cnt
        FROM user_tables
       WHERE table_name =
                   UPPER (i_table_name)
                || '_'
                || TO_CHAR (i_day_of_month, 'yyyymm');

      IF (p_cnt = 0)
      THEN
         p_day_from := TRUNC (i_day_of_month);
         p_day_to := LAST_DAY (TRUNC (i_day_of_month));

         IF (LENGTH (i_table_abbr) > 19)
         THEN
            raise_application_error (
               -20500,
               'Длина аббревиатуры таблицы не может быть больше 19 символов');
         END IF;

         -- Создаем табличное пространство

         p_tablespace :=
               UPPER (i_table_abbr)
            || '_'
            || TO_CHAR (i_day_of_month, 'yyyymm')
            || '_TBL';

         -- Создаем табличное пространство

         p_sql :=
               'CREATE TABLESPACE '
            || p_tablespace
            || ' DATAFILE ''/oradata/SMARTDB/'
            || LOWER (i_table_abbr)
            || TO_CHAR (i_day_of_month, 'yyyymm')
            || '.dbf'' SIZE 4G AUTOEXTEND ON';

         --dbms_output.put_line(p_sql);

         EXECUTE IMMEDIATE p_sql;

         -- Создаем таблицу
         p_sql :=
               'CREATE TABLE '
            || UPPER (i_table_name)
            || '_'
            || TO_CHAR (i_day_of_month, 'yyyymm')
            || '
    ( 
     OP_DATE DATE  NOT NULL,
     STAT_VALUE NUMBER(3)  NOT NULL,
     HOUR VARCHAR(2) NOT NULL
    ) 
    TABLESPACE '
            || p_tablespace
            || ' 
    LOGGING 
    PARTITION BY RANGE ( OP_DATE ) SUBPARTITION BY LIST ( HOUR )';

         p_sql := p_sql || CHR (10) || 'SUBPARTITION TEMPLATE';
         p_sql :=
               p_sql
            || CHR (10)
            || '(SUBPARTITION H00 VALUES(''00'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H01 VALUES(''01'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H02 VALUES(''02'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H03 VALUES(''03'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H04 VALUES(''04'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H05 VALUES(''05'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H06 VALUES(''06'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H07 VALUES(''07'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H08 VALUES(''08'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H09 VALUES(''09'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H10 VALUES(''10'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H11 VALUES(''11'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H12 VALUES(''12'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H13 VALUES(''13'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H14 VALUES(''14'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H15 VALUES(''15'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H16 VALUES(''16'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H17 VALUES(''17'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H18 VALUES(''18'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H19 VALUES(''19'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H20 VALUES(''20'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H21 VALUES(''21'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H22 VALUES(''22'') TABLESPACE '
            || p_tablespace;
         p_sql :=
               p_sql
            || CHR (10)
            || ',SUBPARTITION H23 VALUES(''23'') TABLESPACE '
            || p_tablespace
            || ')';

         p_sql := p_sql || CHR (10) || '(' || CHR (10);

         p_day := p_day_from;

         WHILE p_day <= p_day_to
         LOOP
            IF (p_day != p_day_from)
            THEN
               p_sql := p_sql || CHR (10) || ',';
            END IF;

            p_sql :=
                  p_sql
               || 'PARTITION '
               || UPPER (i_table_abbr)
               || '_'
               || TO_CHAR (p_day, 'yyyymmdd')
               || ' VALUES LESS THAN (to_date('''
               || TO_CHAR (p_day + 1, 'dd.mm.yyyy')
               || ''',''dd.mm.yyyy'')) TABLESPACE '
               || p_tablespace;

            p_day := p_day + 1;
         END LOOP;

         p_sql := p_sql || ' )';

         -- || chr(10);
         --p_sql := p_sql || ')';
         --dbms_output.put_line(p_sql);
         EXECUTE IMMEDIATE p_sql;

         -- Constraints
         p_sql :=
               'ALTER TABLE '
            || UPPER (i_table_name)
            || '_'
            || TO_CHAR (i_day_of_month, 'yyyymm')
            || ' ADD CHECK (STAT_VALUE BETWEEN 0 AND 255)';

         EXECUTE IMMEDIATE p_sql;

         -- Индексы
         --    p_sql := 'CREATE INDEX '
         --     || upper(i_table_abbr)
         --     || '_PK_IDX ON '
         --     || upper(i_table_name)
         --     || '( op_date ASC ) TABLESPACE '
         --     || p_tablespace
         --     || ' LOGGING LOCAL';

         --    EXECUTE IMMEDIATE p_sql;

         -- Primary key
         --    p_sql := 'ALTER TABLE '
         --     || upper(i_table_name)
         --    || ' ADD CONSTRAINT '
         --    || upper(i_table_abbr)
         --    || '_PK PRIMARY KEY ( op_date ) USING INDEX '
         --    || upper(i_table_abbr)
         --    || '_PK_IDX';

         --   EXECUTE IMMEDIATE p_sql;

         -- Quotas
         p_sql := 'ALTER USER SMART QUOTA UNLIMITED ON ' || p_tablespace;

         EXECUTE IMMEDIATE p_sql;
      END IF;
   END create_stat_table;

   PROCEDURE create_all_stat_tables (
      i_day_of_month   IN DATE  /*Дата месяца,за который формируется таблица*/
                               DEFAULT ADD_MONTHS (SYSDATE, 1))
   IS
   BEGIN
      FOR c1 IN (SELECT stat_table_abbr
                   FROM dm_cells
                  WHERE create_stat_table = 'Y')
      LOOP
         create_stat_table (
            i_day_of_month   => i_day_of_month,
            i_table_name     => UPPER (c1.stat_table_abbr) || '_STAT',
            i_table_abbr     => UPPER (c1.stat_table_abbr));
      END LOOP;
   END create_all_stat_tables;
END admin_pkg;
/

