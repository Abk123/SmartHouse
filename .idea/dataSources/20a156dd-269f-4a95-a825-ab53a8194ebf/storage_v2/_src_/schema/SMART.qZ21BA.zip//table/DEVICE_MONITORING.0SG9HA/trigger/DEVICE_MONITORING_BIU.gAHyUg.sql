CREATE TRIGGER DEVICE_MONITORING_BIU
  BEFORE INSERT OR UPDATE
  ON DEVICE_MONITORING
  FOR EACH ROW
  BEGIN
   :New.alarm_on:=upper(:New.alarm_on);
   :New.is_active:=upper(:New.is_active);
   :New.timer_name:=upper(:New.timer_name);
END device_monitoring_biu;
/

