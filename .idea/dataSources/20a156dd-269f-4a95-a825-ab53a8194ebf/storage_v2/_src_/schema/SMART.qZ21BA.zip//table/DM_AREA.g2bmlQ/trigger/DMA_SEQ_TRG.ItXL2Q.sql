CREATE TRIGGER DMA_SEQ_TRG
  BEFORE INSERT
  ON DM_AREA
  FOR EACH ROW
  WHEN (new.dma_id IS NULL)
  BEGIN
    :new.dma_id := dma_seq.nextval;
END;

/

