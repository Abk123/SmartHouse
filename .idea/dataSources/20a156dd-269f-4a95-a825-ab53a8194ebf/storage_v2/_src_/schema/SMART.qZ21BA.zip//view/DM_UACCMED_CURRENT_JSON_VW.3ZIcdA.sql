CREATE VIEW DM_UACCMED_CURRENT_JSON_VW AS
  select json_object('current_time' value to_char(last_update_time,'hh24:mi:ss'), 'current_value' value current_value) ret from (
select max(last_update_time) last_update_time, 
sum(
case
  when cell_name='UACC_MED_VH' then current_value*256
  else current_value
end
)/10 current_value
from dm_cells
where cell_name in('UACC_MED_VL','UACC_MED_VH')
)
/

