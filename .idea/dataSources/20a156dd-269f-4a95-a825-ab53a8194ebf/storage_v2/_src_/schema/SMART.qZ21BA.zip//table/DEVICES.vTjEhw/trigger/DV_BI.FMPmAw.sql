CREATE TRIGGER DV_BI
  BEFORE INSERT
  ON DEVICES
  FOR EACH ROW
  WHEN (new.dv_id IS NULL)
  BEGIN
    :new.dv_id := dv_seq.nextval;
END;

/

