CREATE VIEW DM_CELLS_READ_VW AS
  SELECT
        CASE
            WHEN create_stat_table = 'Y'   THEN upper(stat_table_abbr)
             || '_STAT_'
             || TO_CHAR(
                SYSDATE,
                'yyyymm'
            )
            ELSE CAST(NULL AS VARCHAR2(1) )
        END
    table_name,
    TO_CHAR(
        SYSDATE,
        'hh24'
    ) hour,
    TO_CHAR(
        SYSDATE,
        'dd.mm.yyyy hh24:mi:ss'
    ) date_str,
    cell_name,
    cell_address,
    dmc_id,
    create_stat_table
FROM
    dm_cells
WHERE
    read_enabled = 'Y'
    AND (
      dma_dma_id=1 /*RAM*/ or
      (dma_dma_id=2 /*EEPROM*/ and sysdate-nvl(last_update_time,to_date('01.01.1990','dd.mm.yyyy'))>12/24)
    )
/

