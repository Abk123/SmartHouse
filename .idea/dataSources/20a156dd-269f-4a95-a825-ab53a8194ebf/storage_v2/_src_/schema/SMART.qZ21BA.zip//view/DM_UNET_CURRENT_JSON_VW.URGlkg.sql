CREATE VIEW DM_UNET_CURRENT_JSON_VW AS
  select json_object('current_time' value to_char(last_update_time,'hh24:mi:ss'), 'current_value' value case when current_value=0 then 0 else current_value+100 end) ret from dm_cells where cell_name='UNET'
/

