CREATE TYPE DM_STAT_O AS OBJECT 
( 
op_date date,
stat_value number(3)
)
/

