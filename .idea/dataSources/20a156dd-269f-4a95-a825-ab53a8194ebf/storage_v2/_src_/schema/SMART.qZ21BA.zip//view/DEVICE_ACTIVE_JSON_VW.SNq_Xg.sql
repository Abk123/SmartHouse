CREATE VIEW DEVICE_ACTIVE_JSON_VW AS
  select json_object('dominator' value max(dominator), 'wnr3500l' value max(wnr3500l), 'ps1810_8g' value max(ps1810_8g),
  'wn2500rp' value max(wn2500rp), 'abk_macbook' value max(abk_macbook), 'lera_mobile' value max(lera_mobile),
  'abk_mobile' value max(abk_mobile), 'natasha_mobile' value max(natasha_mobile), 'abk_ipad' value max(abk_ipad),
  'tl_wa850re' value max(tl_wa850re), 'natasha_notebook' value max(natasha_notebook), 'hp_ilo' value max(hp_ilo),
  'sms' value max(sms)) ret
from
(
select
case
  when dv_abbr='DOMINATOR' and active='N' then 'N'
  when dv_abbr='DOMINATOR' then active
end dominator,
case
  when dv_abbr='WNR3500L' and active='N' then 'N'
  when dv_abbr='WNR3500L' then active
end wnr3500l,
case
  when dv_abbr='PS1810_8G' and active='N' then 'N'
  when dv_abbr='PS1810_8G' then active
end ps1810_8g,
case
  when dv_abbr='WN2500RP' and active='N' then 'N'
  when dv_abbr='WN2500RP' then active
end wn2500rp,
case
  when dv_abbr='ABK_MACBOOK' and active='N' then 'N'
  when dv_abbr='ABK_MACBOOK' then active
end abk_macbook,
case
  when dv_abbr='LERA_MOBILE' and active='N' then 'N'
  when dv_abbr='LERA_MOBILE' then active
end lera_mobile,
case
  when dv_abbr='ABK_MOBILE' and active='N' then 'N'
  when dv_abbr='ABK_MOBILE' then active
end abk_mobile,
case
  when dv_abbr='NATASHA_MOBILE' and active='N' then 'N'
  when dv_abbr='NATASHA_MOBILE' then active
end natasha_mobile,
case
  when dv_abbr='ABK_IPAD' and active='N' then 'N'
  when dv_abbr='ABK_IPAD' then active
end abk_ipad,
case
  when dv_abbr='TL_WA850RE' and active='N' then 'N'
  when dv_abbr='TL_WA850RE' then active
end tl_wa850re,
case
  when dv_abbr='NATASHA_NOTEBOOK' and active='N' then 'N'
  when dv_abbr='NATASHA_NOTEBOOK' then active
end natasha_notebook,
case
  when dv_abbr='HP_ILO' and active='N' then 'N'
  when dv_abbr='HP_ILO' then active
end hp_ilo,
case
  when dv_abbr='SMS' and active='N' then 'N'
  when dv_abbr='SMS' then active
end sms
from devices
)
/

