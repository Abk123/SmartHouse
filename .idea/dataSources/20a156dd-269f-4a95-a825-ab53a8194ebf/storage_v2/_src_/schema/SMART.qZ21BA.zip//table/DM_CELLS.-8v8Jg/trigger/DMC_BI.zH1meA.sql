CREATE TRIGGER DMC_BI
  BEFORE INSERT
  ON DM_CELLS
  FOR EACH ROW
  WHEN (new.dmc_id IS NULL)
  BEGIN
    :new.dmc_id := dmc_seq.nextval;
END;

/

