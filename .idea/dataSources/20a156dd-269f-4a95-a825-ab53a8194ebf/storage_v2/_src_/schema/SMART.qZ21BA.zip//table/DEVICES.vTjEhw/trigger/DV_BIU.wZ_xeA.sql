CREATE TRIGGER DV_BIU
  BEFORE INSERT OR UPDATE
  ON DEVICES
  FOR EACH ROW
  begin
  :New.enabled:=upper(:New.enabled);
  :New.active:=upper(:New.active);
  :New.dv_abbr:=upper(:New.dv_abbr);
end;
/

