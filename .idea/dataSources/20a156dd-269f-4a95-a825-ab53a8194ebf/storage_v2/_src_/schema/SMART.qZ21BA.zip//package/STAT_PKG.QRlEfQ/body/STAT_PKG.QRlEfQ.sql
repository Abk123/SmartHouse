CREATE PACKAGE BODY       stat_pkg
AS
   -- Получить статистические данные ячейки памяти Доминатора

   FUNCTION get_data (i_cell_name   IN VARCHAR2     /*Название ячейки памяти*/
                                               ,
                      i_date_from   IN DATE                         /*Дата С*/
                                           ,
                      i_date_to     IN DATE                        /*Дата По*/
                                           )
      RETURN dm_stat_oc
   IS
      p_ret          dm_stat_oc;
      pd1            DATE;
      pd2            DATE;
      pd             DATE;
      p_table_name   VARCHAR2 (50);
      i              NUMBER;
      p_sql          VARCHAR2 (32000);
   BEGIN
      -- Формируем список таблиц для поиска данных
      pd1 := TRUNC (i_date_from, 'mm');
      pd2 := TRUNC (i_date_to, 'mm');
      pd := pd1;
      i := 0;

      WHILE (pd <= pd2)
      LOOP
         BEGIN
            SELECT table_name
              INTO p_table_name
              FROM user_tables
             WHERE     REGEXP_LIKE (table_name, UPPER (i_cell_name))
                   AND REGEXP_REPLACE (table_name,
                                       UPPER (i_cell_name) || '_STAT_') =
                          TO_CHAR (pd, 'yyyymm');

            IF (i = 0)
            THEN
               p_sql := 'select dm_stat_o(op_date,stat_value) from ( 
select op_date,stat_value from ' || p_table_name;
            ELSE
               p_sql :=
                     p_sql
                  || CHR (10)
                  || 'union all'
                  || CHR (10)
                  || 'select op_date,stat_value from '
                  || p_table_name;
            END IF;

            i := i + 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               NULL;
         END;

         pd := ADD_MONTHS (pd, 1);
      END LOOP;

      p_sql :=
            p_sql
         || CHR (10)
         || ')'
         || CHR (10)
         || 'where op_date between :1 and :2 order by op_date';

      DBMS_OUTPUT.put_line (p_sql);

      EXECUTE IMMEDIATE p_sql
         BULK COLLECT INTO p_ret
         USING i_date_from, i_date_to;

      RETURN p_ret;
   END;

   -- Получить статистические данные в виде CLOB

   FUNCTION get_clob_data (i_cell_name   IN VARCHAR2 /*Название ячейки памяти*/
                                                    ,
                           i_date_from   IN DATE                    /*Дата С*/
                                                ,
                           i_date_to     IN DATE                   /*Дата По*/
                                                )
      RETURN CLOB
   IS
      p_result     CLOB;
      p_interval   NUMBER;
   BEGIN
      p_result := NULL;

      -- Определим интервал времени,по которому группировать данные
      SELECT CEIL (AVG ( (MAX - MIN) * 24 * 60) / 1) * 1
        INTO p_interval
        FROM (  SELECT MIN (op_date) MIN,
                       MAX (op_date) MAX,
                       COUNT (*) cnt,
                       nt
                  FROM (SELECT op_date, NTILE (60 -- должны получить 50 диапазонов максимум. иначе все сольется на графике
                                                 ) OVER (ORDER BY op_date) nt
                          FROM TABLE (
                                  stat_pkg.get_data (i_cell_name,
                                                     i_date_from,
                                                     i_date_to)))
              GROUP BY nt);

      -- Приступаем к генерации данных в зависимости от названия ячейки

      IF (i_cell_name = 'PNETL')
      THEN
         SELECT json_arrayagg (json_object ('op_date' value to_char(op_date,'dd.mm.yyyy hh24:mi:ss'),
                'stat_value' value stat_value) returning clob) into p_result
            from
            (
                select op_date, stat_value,  row_number() over(order by op_date) r_num
                from
                (
                    select to_date('31.12.2999','dd.mm.yyyy') - ceil((to_date('31.12.2999','dd.mm.yyyy')-op_date)*24*60/p_interval)*p_interval/24/60 op_date,
                        round(avg(stat_value)) stat_value
                    from
                    (
                        select op_date, stat_value*100 stat_value
                        from table(stat_pkg.get_data('PNETL', i_date_from, i_date_to))
                    )
                    group by to_date('31.12.2999','dd.mm.yyyy') - ceil((to_date('31.12.2999','dd.mm.yyyy')-op_date)*24*60/p_interval)*p_interval/24/60
                )
            )
            order by r_num;
        elsif(i_cell_name='UNET') then
            select json_arrayagg(json_object('op_date' value to_char(op_date,'dd.mm.yyyy hh24:mi:ss'),
                'stat_value' value stat_value) returning clob) into p_result
            from
            (
                select op_date, stat_value,  row_number() over(order by op_date) r_num
                from
                (
                    select to_date('31.12.2999','dd.mm.yyyy') - ceil((to_date('31.12.2999','dd.mm.yyyy')-op_date)*24*60/p_interval)*p_interval/24/60 op_date,
                        round(avg(stat_value)) stat_value
                    from
                    (
                        select op_date,
                          case
                            when stat_value=0 then 0 else stat_value+100
                          end stat_value
                        from table(stat_pkg.get_data('UNET', i_date_from, i_date_to))
                    )
                    group by to_date('31.12.2999','dd.mm.yyyy') - ceil((to_date('31.12.2999','dd.mm.yyyy')-op_date)*24*60/p_interval)*p_interval/24/60
                )
            )
            order by r_num;
        elsif(i_cell_name='UOUTMED') then
            select json_arrayagg(json_object('op_date' value to_char(op_date,'dd.mm.yyyy hh24:mi:ss'),
                'stat_value' value stat_value) returning clob) into p_result
            from
            (
                select op_date, stat_value,  row_number() over(order by op_date) r_num
                from
                (
                    select to_date('31.12.2999','dd.mm.yyyy') - ceil((to_date('31.12.2999','dd.mm.yyyy')-op_date)*24*60/p_interval)*p_interval/24/60 op_date,
                        round(avg(stat_value)) stat_value
                    from
                    (
                        select op_date,
                          case
                            when stat_value=0 then 0 else stat_value+100
                          end stat_value
                        from table(stat_pkg.get_data('UOUTMED', i_date_from, i_date_to))
                    )
                    group by to_date('31.12.2999','dd.mm.yyyy') - ceil((to_date('31.12.2999','dd.mm.yyyy')-op_date)*24*60/p_interval)*p_interval/24/60
                )
            )
            order by r_num;
        elsif(i_cell_name='INET') then
            select json_arrayagg(json_object('op_date' value to_char(op_date,'dd.mm.yyyy hh24:mi:ss'),
                'stat_value' value stat_value) returning clob) into p_result
            from
            (
                select op_date, stat_value,  row_number() over(order by op_date) r_num
                from
                (
                    select to_date('31.12.2999','dd.mm.yyyy') - ceil((to_date('31.12.2999','dd.mm.yyyy')-op_date)*24*60/p_interval)*p_interval/24/60 op_date,
                        round(avg(stat_value)) stat_value
                    from
                    (
                        select op_date, stat_value
                        from table(stat_pkg.get_data('INET', i_date_from, i_date_to))
                    )
                    group by to_date('31.12.2999','dd.mm.yyyy') - ceil((to_date('31.12.2999','dd.mm.yyyy')-op_date)*24*60/p_interval)*p_interval/24/60
                )
            )
            order by r_num;
        end if;

        RETURN p_result;
    END;

END stat_pkg;
/

