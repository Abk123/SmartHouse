CREATE VIEW SMS_DEVICE_INFO_JSON_VW AS
  SELECT json_object ('ip' value max(ip), 'update_time' value max(update_time),
'mobile_phone' value max(mobile_phone),'emergency_phone' value max(emergency_phone),
'selftest_on_init' value max(selftest_on_init)) ret
from
(
SELECT CASE WHEN dp.pr_id = 2 THEN dp.value_string END ip,
       CASE WHEN dp.pr_id = 3 THEN dp.value_number END update_time,
       CASE WHEN dp.pr_id = 8 THEN dp.value_string END mobile_phone,
       CASE WHEN dp.pr_id = 9 THEN dp.value_string END emergency_phone,
       CASE WHEN dp.pr_id = 10 THEN dp.value_string END selftest_on_init
  FROM device_properties dp
 WHERE dp.dv_id = 13
)                                                                        -- SMS
/

