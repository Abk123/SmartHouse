CREATE PACKAGE       admin_pkg
AS
   PROCEDURE create_stat_table (i_day_of_month   IN DATE /*Дата месяца,за который формируется таблица*/
                                                        ,
                                i_table_name     IN VARCHAR2 /*Наименование таблицы*/
                                                            ,
                                i_table_abbr     IN VARCHAR2 /*Аббревиатура таблицы*/
                                                            );

   PROCEDURE create_all_stat_tables (
      i_day_of_month   IN DATE  /*Дата месяца,за который формируется таблица*/
                               DEFAULT ADD_MONTHS (SYSDATE, 1));
END;
/

