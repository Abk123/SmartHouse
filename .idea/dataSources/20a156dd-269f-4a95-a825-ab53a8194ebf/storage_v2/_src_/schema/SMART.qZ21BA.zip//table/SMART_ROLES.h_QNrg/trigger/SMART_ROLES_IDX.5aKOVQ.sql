CREATE TRIGGER SMART_ROLES_IDX
  BEFORE INSERT OR UPDATE
  ON SMART_ROLES
  FOR EACH ROW
  begin
  :New.role_name:=upper(:New.role_name);
end;

/

