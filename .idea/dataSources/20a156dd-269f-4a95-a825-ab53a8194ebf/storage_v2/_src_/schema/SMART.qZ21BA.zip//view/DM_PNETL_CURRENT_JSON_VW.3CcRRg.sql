CREATE VIEW DM_PNETL_CURRENT_JSON_VW AS
  select json_object('current_time' value to_char(last_update_time,'hh24:mi:ss'), 'current_value' value current_value*100) ret from dm_cells where cell_name='PNET_L'
/

