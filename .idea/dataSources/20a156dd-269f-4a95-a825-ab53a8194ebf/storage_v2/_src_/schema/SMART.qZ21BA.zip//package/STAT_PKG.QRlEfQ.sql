CREATE PACKAGE       stat_pkg
AS
   -- Получить статистические данные ячейки памяти Доминатора
   FUNCTION get_data (i_cell_name   IN VARCHAR2     /*Название ячейки памяти*/
                                               ,
                      i_date_from   IN DATE                         /*Дата С*/
                                           ,
                      i_date_to     IN DATE                        /*Дата По*/
                                           )
      RETURN dm_stat_oc;

   -- Получить статистические данные в виде CLOB

   FUNCTION get_clob_data (i_cell_name   IN VARCHAR2 /*Название ячейки памяти*/
                                                    ,
                           i_date_from   IN DATE                    /*Дата С*/
                                                ,
                           i_date_to     IN DATE                   /*Дата По*/
                                                )
      RETURN CLOB;
END stat_pkg;
/

