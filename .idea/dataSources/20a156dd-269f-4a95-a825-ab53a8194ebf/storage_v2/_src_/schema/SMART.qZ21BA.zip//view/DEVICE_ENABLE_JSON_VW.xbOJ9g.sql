CREATE VIEW DEVICE_ENABLE_JSON_VW AS
  SELECT json_object ('dominator' value max(dominator), 'wnr3500l' value max(wnr3500l), 'ps1810_8g' value max(ps1810_8g),
  'wn2500rp' value max(wn2500rp), 'abk_macbook' value max(abk_macbook), 'lera_mobile' value max(lera_mobile),
  'abk_mobile' value max(abk_mobile), 'natasha_mobile' value max(natasha_mobile), 'abk_ipad' value max(abk_ipad),
  'tl_wa850re' value max(tl_wa850re), 'natasha_notebook' value max(natasha_notebook), 'hp_ilo' value max(hp_ilo),
  'sms' value max(sms)) ret
from
(
select
case
  when dv_abbr='DOMINATOR' and enabled='N' then 'N'
  when dv_abbr='DOMINATOR' then enabled
end dominator,
case
  when dv_abbr='WNR3500L' and enabled='N' then 'N'
  when dv_abbr='WNR3500L' then enabled
end wnr3500l,
case
  when dv_abbr='PS1810_8G' and enabled='N' then 'N'
  when dv_abbr='PS1810_8G' then enabled
end ps1810_8g,
case
  when dv_abbr='WN2500RP' and enabled='N' then 'N'
  when dv_abbr='WN2500RP' then enabled
end wn2500rp,
case
  when dv_abbr='ABK_MACBOOK' and enabled='N' then 'N'
  when dv_abbr='ABK_MACBOOK' then enabled
end abk_macbook,
case
  when dv_abbr='LERA_MOBILE' and enabled='N' then 'N'
  when dv_abbr='LERA_MOBILE' then enabled
end lera_mobile,
case
  when dv_abbr='ABK_MOBILE' and enabled='N' then 'N'
  when dv_abbr='ABK_MOBILE' then enabled
end abk_mobile,
case
  when dv_abbr='NATASHA_MOBILE' and enabled='N' then 'N'
  when dv_abbr='NATASHA_MOBILE' then enabled
end natasha_mobile,
case
  when dv_abbr='ABK_IPAD' and enabled='N' then 'N'
  when dv_abbr='ABK_IPAD' then enabled
end abk_ipad,
case
  when dv_abbr='TL_WA850RE' and enabled='N' then 'N'
  when dv_abbr='TL_WA850RE' then enabled
end tl_wa850re,
case
  when dv_abbr='NATASHA_NOTEBOOK' and enabled='N' then 'N'
  when dv_abbr='NATASHA_NOTEBOOK' then enabled
end natasha_notebook,
case
  when dv_abbr='HP_ILO' and enabled='N' then 'N'
  when dv_abbr='HP_ILO' then enabled
end hp_ilo,
case
  when dv_abbr='SMS' and enabled='N' then 'N'
  when dv_abbr='SMS' then enabled
end sms
from devices
)
/

