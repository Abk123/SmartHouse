CREATE VIEW DM_DEVICE_INFO_JSON_VW AS
  SELECT json_object ('verpow' value max(verpow), 'verpo' value max(verpo) , 'pow' value max(pow) ,
  'uacc' value max(uacc) , 'devopt' value max(devopt) , 'verplatpic' value max(verplatpic) , 'verplatnet' value max(verplatnet),
  'em_temp_okr' value max(em_temp_okr), 'em_temp_top' value max(em_temp_top), 'em_temp_trad' value max(em_temp_trad),
  't_charge' value max(t_charge), 't_net_on' value max(t_net_on), 't_accdisch' value max(t_accdisch),
  'port' value max(port)) ret
from (
select current_value, case
  when cell_name='VERPOW' then (bitand(current_value,1) + bitand(current_value,2) +
    bitand(current_value,4) + bitand(current_value,8) + bitand(current_value,16) +
    bitand(current_value,32)) || case when bitand(current_value, 128)=128 then ' hybrid' end
end verpow,
case
  when cell_name='VERPO' then (bitand(current_value,1) + bitand(current_value,2) +
    bitand(current_value,4) + bitand(current_value,8) + bitand(current_value,16)) ||
    '.' || (bitand(current_value,32)/32 + bitand(current_value,64)/64*2 + bitand(current_value,128)/128*4)
end verpo,
case
  when cell_name='POW' and current_value=0 then '1.3'
  when cell_name='POW' and current_value=1 then '1.5'
  when cell_name='POW' and current_value=2 then '2'
  when cell_name='POW' and current_value=3 then '3'
  when cell_name='POW' and current_value=4 then '4.5'
  when cell_name='POW' and current_value=5 then '6'
  when cell_name='POW' and current_value=6 then '9'
  when cell_name='POW' and current_value=7 then '12'
  when cell_name='POW' and current_value=8 then '15'
  when cell_name='POW' and current_value=9 then '16'
  when cell_name='POW' and current_value=10 then '24'
  when cell_name='POW' and current_value=11 then '32'
end pow,
case
  when cell_name='UACC' and current_value=0 then '12'
  when cell_name='UACC' and current_value=1 then '24'
  when cell_name='UACC' and current_value=2 then '48'
  when cell_name='UACC' and current_value=3 then '96'
end uacc,
case
  when cell_name='DEVOPT' then current_value
end devopt,
case
  when cell_name='VERPLATPIC' then current_value
end verplatpic,
case
  when cell_name='VERPLATNET' then (bitand(current_value,1) + bitand(current_value,2) +
    bitand(current_value,4)+6) || case when bitand(current_value,8)=8 then ' hi' else ' low'end
end verplatnet,
case
  when cell_name='MASK_DEV_ON' and bitand(current_value, 1)=1 then 'ON'
  else 'OFF'
end em_temp_okr,
case
  when cell_name='MASK_DEV_ON' and bitand(current_value, 2)=2 then 'ON'
  else 'OFF'
end em_temp_top,
case
  when cell_name='MASK_DEV_ON' and bitand(current_value, 4)=4 then 'ON'
  else 'OFF'
end em_temp_trad,
case
  when cell_name='T_CHARGE' then current_value
end t_charge,
case
  when cell_name='T_NET_ON' then current_value
end t_net_on,
case
  when cell_name='T_ACCDISCH' then current_value
end t_accdisch,
null port
from dm_cells
where cell_name in('VERPOW', 'VERPO', 'POW', 'UACC', 'VERPLATPIC', 'VERPLATNET',
 'MASK_DEV_ON', 'DEVOPT', 'MASK_DEV_ON', 'T_CHARGE', 'T_NET_ON', 'T_ACCDISCH')
 
union all

select null current_value, null verpow,null verpo,null pow,null uacc,null devopt,null verplatpic,null verplatnet,
  null em_temp_okr,null em_temp_top,null em_temp_trad,null t_charge,null t_net_on,null t_accdisch ,
  dp.value_string port
from DEVICE_PROPERTIES dp
where dp.dv_id=1
 and dp.pr_id=5
)
/

