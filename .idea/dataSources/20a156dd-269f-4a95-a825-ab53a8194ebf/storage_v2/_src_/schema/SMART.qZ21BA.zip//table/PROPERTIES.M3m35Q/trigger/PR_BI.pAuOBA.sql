CREATE TRIGGER PR_BI
  BEFORE INSERT
  ON PROPERTIES
  FOR EACH ROW
  WHEN (new.pr_id IS NULL)
  BEGIN
    :new.pr_id := pr_seq.nextval;
END;

/

