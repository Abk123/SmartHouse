CREATE TRIGGER DMA_BIU
  BEFORE INSERT OR UPDATE
  ON DM_AREA
  FOR EACH ROW
  BEGIN
    :new.read_enabled := upper(:new.read_enabled);
    :new.write_enabled := upper(:new.write_enabled);
    :new.area_name := upper(:new.area_name);
END;
/

