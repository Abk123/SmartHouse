CREATE TRIGGER BI
  BEFORE INSERT
  ON DEVICE_MONITORING
  FOR EACH ROW
  WHEN (new.id IS NULL)
  BEGIN
    :new.id := mntr_seq.nextval;
END;

/

