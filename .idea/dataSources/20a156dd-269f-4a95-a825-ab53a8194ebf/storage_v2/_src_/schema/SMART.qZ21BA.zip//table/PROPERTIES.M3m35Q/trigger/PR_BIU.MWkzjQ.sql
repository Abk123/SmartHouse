CREATE TRIGGER PR_BIU
  BEFORE INSERT OR UPDATE
  ON PROPERTIES
  FOR EACH ROW
  begin
  :New.pr_abbr:=upper(:New.pr_abbr);
end;

/

