CREATE VIEW DM_ACCTEMP_CURRENT_JSON_VW AS
  select json_object('current_time' value to_char(last_update_time,'hh24:mi:ss'), 'current_value' value current_value) ret
from
(
SELECT
    last_update_time,
        CASE
            WHEN (
                SELECT
                    bitand(
                        current_value,
                        1
                    )
                FROM
                    dm_cells
                WHERE
                    cell_name = 'TEMP_OFF'
            ) = 1THEN 0
            ELSE current_value - 50
        END
    current_value
FROM
    dm_cells
WHERE
    cell_name = 'TEMP_GRAD0'

)
/

